Readme.txt

-------------------------------------------------------------------
Release : 10.07.0020 Halon
Last Updated Date : Jul 26th, 2021.

This file outlines changes since the last release of MIBs.

It is very strongly recommended that you load and compile ALL of
the MIBs provided.
-------------------------------------------------------------------
List of new objects supported in this release : None
List of new traps supported in this release   : None
